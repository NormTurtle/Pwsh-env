## Installation

You can download the released `zip` file and extract it to the `mpv/scripts` directory or run `make install`. See [Installation](https://github.com/Ajatt-Tools/mpvacious#installation) for details.

## Issues

If you face any problems when installing or using mpvacious, [ask in our chat](https://tatsumoto.neocities.org/blog/join-our-community.html)!

## Support my work

I would not have been able to develop this add-on without the support of my patrons. Thanks so much!

<p align="center">
<a href="https://tatsumoto.neocities.org/blog/donating-to-tatsumoto.html" rel="nofollow"><img alt="Patreon" src="https://i.imgur.com/qkNP40F.png"></a>
<a href="https://github.com/Ajatt-Tools" rel="nofollow"><img src="https://user-images.githubusercontent.com/69171671/92849452-ddedf100-f3da-11ea-9405-ee17460751f9.png"></a>
<a href="https://tatsumoto.neocities.org/blog/join-our-community" rel="nofollow"><img src="https://tatsumoto.neocities.org/blog/img/join_us_on_element_220x51.png"></a>
</p>

## Changes
