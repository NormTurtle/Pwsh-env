local lazypath = vim.fn.stdpath("data") .. "/lazy/lazy.nvim"
if not vim.loop.fs_stat(lazypath) then
	vim.fn.system({
		"git",
		"clone",
		"--filter=blob:none",
		"https://github.com/folke/lazy.nvim.git",
		"--branch=stable", -- latest stable release
		lazypath,
	})
end
vim.opt.rtp:prepend(lazypath)

require("lazy").setup({

	{ -- Tab Line
		"romgrk/barbar.nvim",
		dependencies = { "nvim-tree/nvim-web-devicons" },
	},
})

local map = vim.api.nvim_set_keymap
local opts = { noremap = true, silent = true }

-- Move to previous/next
map("n", "<A-,>", "<Cmd>BufferPrevious<CR>", opts)
map("n", "<A-.>", "<Cmd>BufferNext<CR>", opts)
-- Pin/unpin buffer
map("n", "<A-S-p>", "<Cmd>BufferPin<CR>", opts)
-- Close buffer
map("n", "<A-z>", "<Cmd>BufferClose<CR>", opts)
map("n", "<C-p>", "<Cmd>BufferPick<CR>", opts)

-- Re-order to previous/next
map("n", "<A-<>", "<Cmd>BufferMovePrevious<CR>", opts)
map("n", "<A->>", "<Cmd>BufferMoveNext<CR>", opts)

vim.keymap.set("n", "to", ":tabnew<CR>") -- open new Tab
vim.keymap.set("n", "tx", ":tabclose<CR>") -- close current tab
vim.keymap.set("n", "tn", ":tabn<CR>") -- go to next tab
vim.keymap.set("n", "tp", ":tabp<CR>") -- go to prev tab
