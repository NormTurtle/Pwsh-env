# Komorebi Application-Specific Configuration

A community-driven repository for users to share application-specific
[komorebi](https://github.com/LGUG2Z/komorebi) configuration options, with the
goal of creating an tiling window management experience on Windows that "just
works" for as many applications as possible.
