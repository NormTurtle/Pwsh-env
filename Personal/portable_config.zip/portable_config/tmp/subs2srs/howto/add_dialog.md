# Open the "Add" dialog

1) Open a video in `mpv`.
1) Press <kbd>a</kbd> to open advanced menu.
1) Optionally, press <kbd>c</kbd> and select the desired subtitle lines with the interactive selection.
1) Press <kbd>g</kbd> to open the Add dialog in Anki.
1) Add dictionary definitions using software like GoldenDict, Qolibri, etc.

After the card is created, you can find it by typing `added:1` in the Anki Browser.
